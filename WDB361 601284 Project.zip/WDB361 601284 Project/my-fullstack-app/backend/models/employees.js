const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  surname: { type: String },
  gender: { type: String },
  department: { type: String },
  salary: { type: Number },
}, {
  timestamps: true,
  collection: 'employee'
});

module.exports = mongoose.model('Employee', employeeSchema);
