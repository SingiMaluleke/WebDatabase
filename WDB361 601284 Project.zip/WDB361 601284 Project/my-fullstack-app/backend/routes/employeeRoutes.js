const express = require('express');
const router = express.Router();
const Employee = require('../models/employees');

// GET all employees
router.get('/', async (req, res) => {
  try {
    const employees = await Employee.find();
    res.json(employees);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET a single employee by ID
router.get('/:id', async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    res.json(employee);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// CREATE a new employee
router.post('/', async (req, res) => {
  const employee = new Employee({
  name: req.body.name,
  surname: req.body.surname,
  gender: req.body.gender,
  department: req.body.department,
  salary: req.body.salary,
});


  try {
    const newEmployee = await employee.save();
    res.status(201).json(newEmployee);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// UPDATE employee by ID (full update)
router.put('/:id', async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    // Update all fields
    employee.name = req.body.name;
    employee.surname = req.body.surname;
    employee.gender = req.body.gender;
    employee.department = req.body.department;
    employee.salary = req.body.salary;

    const updatedEmployee = await employee.save();
    res.json(updatedEmployee);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});



// DELETE an employee by ID
router.delete('/:id', async (req, res) => {
  console.log('Delete request received for ID:', req.params.id);
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    await Employee.findByIdAndDelete(req.params.id);
    res.json({ message: 'Employee deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


module.exports = router;

