import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Employees.css';

/* with this code, i wanted to create a lovely crud system. 
To be honest i used my WSE361 code and just added more to it, thought why not get more creative with time
Although my update button doesnt fully work, what do they say about what is not broken
The update only updates one character which is the name and does nothing to the rest*/

function AddEmployee() {
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    gender: '',
    department: '',
    salary: ''
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = () => {
    axios.get('http://localhost:5000/api/employees')
      .then(res => setEmployees(res.data))
      .catch(err => console.error(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (editingId) {
      // Update
      axios.put(`http://localhost:5000/api/employees/${editingId}`, {
        ...formData,
        salary: parseFloat(formData.salary)
      })
        .then(() => {
          fetchEmployees();
          setEditingId(null);
          setFormData({ name: '', surname: '', gender: '', department: '', salary: '' });
        })
        .catch(err => console.error('Failed to update employee:', err));
    } else {
      // Add new
      axios.post('http://localhost:5000/api/employees', {
        ...formData,
        salary: parseFloat(formData.salary)
      })
        .then(res => {
          setEmployees(prev => [...prev, res.data]);
          setFormData({ name: '', surname: '', gender: '', department: '', salary: '' });
        })
        .catch(err => console.error('Failed to save employee:', err));
    }
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/api/employees/${id}`)
      .then(() => {
        setEmployees(prev => prev.filter(emp => emp._id !== id));
      })
      .catch(err => console.error('Delete error:', err));
  };

  const handleEdit = (employee) => {
    setFormData({
      name: employee.name,
      surname: employee.surname,
      gender: employee.gender,
      department: employee.department,
      salary: employee.salary
    });
    setEditingId(employee._id);
  };

  const handleClear = () => {
    setFormData({ name: '', surname: '', gender: '', department: '', salary: '' });
    setEditingId(null);
  };

  const filteredEmployees = employees.filter(emp =>
    emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.surname.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="employees-container">
      <h2>{editingId ? 'Update Employee' : 'Add New Employee'}</h2>
      <p>Fill in the details below to {editingId ? 'update' : 'add'} an employee.</p>

      <form onSubmit={handleSubmit} className="employee-form">
        <input
          type="text"
          placeholder="Name"
          value={formData.name}
          onChange={e => setFormData({ ...formData, name: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Surname"
          value={formData.surname}
          onChange={e => setFormData({ ...formData, surname: e.target.value })}
          required
        />
        <select
          value={formData.gender}
          onChange={e => setFormData({ ...formData, gender: e.target.value })}
          required
        >
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
        <select
          value={formData.department}
          onChange={e => setFormData({ ...formData, department: e.target.value })}
          required
        >
          <option value="">Select Department</option>
          <option value="Engineering">Engineering</option>
          <option value="Marketing">Marketing</option>
          <option value="Finance">Finance</option>
          <option value="HR">Human Resource</option>
          <option value="IT">Information Technology</option>
        </select>
        <input
          type="number"
          placeholder="Salary"
          value={formData.salary}
          onChange={e => setFormData({ ...formData, salary: e.target.value })}
          required
        />
        <button type="submit">{editingId ? 'Update' : 'Add'}</button>
        <button type="button" onClick={handleClear}>Clear</button>
      </form>

      <input
        type="text"
        placeholder="Search by name or surname..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
        className="search-input"
      />

      <h3>Current Employees</h3>
      <table className="employees-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Surname</th>
            <th>Gender</th>
            <th>Department</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map(emp => (
            <tr key={emp._id}>
              <td>{emp.name}</td>
              <td>{emp.surname}</td>
              <td>{emp.gender}</td>
              <td>{emp.department}</td>
              <td>{emp.salary.toLocaleString('en-ZA', {
                style: 'currency',
                currency: 'ZAR'
              })}</td>
              <td>
                <button onClick={() => handleEdit(emp)} className="edit-btn">Edit</button>
                <button onClick={() => handleDelete(emp._id)} className="delete-btn">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AddEmployee;
