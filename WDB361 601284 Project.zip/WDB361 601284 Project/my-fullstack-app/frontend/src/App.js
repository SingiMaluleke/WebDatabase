import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes, NavLink } from 'react-router-dom';
import Home from './components/Home';
import Employees from './components/Employees';
import Department from './components/Department';
import AddEmployee from './components/AddEmployees';

function App() {
  return (
    <Router>
      <div>
        <header className="header">
          <div className="logo">Employee Portal</div>
          <nav className="navbar">
            <NavLink to="/" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} end>Home</NavLink>
            <NavLink to="/employees" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>All Employees</NavLink>
            <NavLink to="/department/Engineering" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Engineering</NavLink>
            <NavLink to="/department/Marketing" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Marketing</NavLink>
            <NavLink to="/department/Finance" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Finance</NavLink>
            <NavLink to="/add-employee" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Add Employee</NavLink>
          </nav>
        </header>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/department/:departmentName" element={<Department />} />
            <Route path="/add-employee" element={<AddEmployee />} />
            <Route path="*" element={<h2>404: Page Not Found</h2>} />
          </Routes>
        </main>
      </div>
      </Router>

  );
}

export default App;

